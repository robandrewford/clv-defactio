"""
CLV Defactio - Customer Lifetime Value Prediction System

This package contains modules for data processing, pipeline management,
and machine learning model development.
"""

__version__ = "0.1.0"
